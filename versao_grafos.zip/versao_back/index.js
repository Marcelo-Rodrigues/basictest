const express = require('express');
const bodyParser = require('body-parser')
var path = require('path')
const app = express();


//BD
var Connection = require('tedious').Connection;
var config = {
  userName: 'Poc',
  password: '123456',
  server: '192.168.1.100',
  database: 'PocRelac',
  options:
    {
      database: 'PocRelac',
      instanceName: "SQLEXPRESS",
      rowCollectionOnRequestCompletion: true
    }
};
var connection = new Connection(config);
var Request = require('tedious').Request
var TYPES = require('tedious').TYPES;


app.use(bodyParser.json());

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.set('port', (process.env.PORT || 8080));

app.get('/api/cluster', function (req, res) {

  consultarClusters(function (resCluster) {
    if (resCluster) {
      res.send(resCluster);
    } else {
      res.status(500).send({
        message: 'Falha durante a execução'
      });
    }
  }, +req.query.codigoTipoCluster, req.query.codigoCluster, req.query.anoMes);
});

function consultarClusters(callback, codigoTipoCluster, codigoCluster, anoMesVigencia) {
  var connection = new Connection(config);
  connection.on('connect', function (err) {

    if (err) {
      console.log('erro durante a conexao: ', err);
      return;
    }

    // const request = new Request("dbo.[ConsultaGrafoClusterCluster_SR] @CODIGO_TIPO_CLUSTER, @CODIGO_CLUSTER, @ANOMES_VIGENCIA", function (err, rowCount, rows) {
    const request = new Request("dbo.[ConsultaGrafoClusterCluster]", function (err, rowCount, rows) {
      if (err) {
        console.log(err);
        callback(null);
      } else {
        callback(converterGrafo(rows));
      }
      connection.close();
    });
    request.addParameter('CODIGO_TIPO_CLUSTER', TYPES.Int, codigoTipoCluster);
    request.addParameter('CODIGO_CLUSTER', TYPES.Char, codigoCluster);
    request.addParameter('ANOMES_VIGENCIA', TYPES.Int, anoMesVigencia);
    connection.callProcedure(request)
  });
}

function converterGrafo(rows) {
  const vertices = rows.filter(linha => linha[0].metadata.colName === 'CODIGO_CLUSTER')
    .map(linha => {
      return {
        data: { id: linha[0].value, descricao: linha[1].value }
      };
    });
  const arestas = rows.filter(linha => linha[0].metadata.colName === 'CODIGO_CLUSTER_ORIGEM')
    .map(linha => {
      return {
        data: {
          source: linha[0].value,
          target: linha[1].value,
          valor: linha[2].value,
          id_tipo_pagamento: linha[3].value,
          descricao: linha[4].value
        }
      };
    });
  return vertices.concat(arestas);
}

app.use(express.static(path.resolve('..', 'relacoes', 'dist')));

// app.get('**', function (req, res) {
//   res.sendFile(path.resolve('..', 'relacoes', 'dist', 'index.html'));
// });

app.listen(app.get('port'), function () {
  console.log('Server Poc Grafo iniciado na porta ', app.get('port'));
  console.log(`http://localhost:${app.get('port')}/`);
});