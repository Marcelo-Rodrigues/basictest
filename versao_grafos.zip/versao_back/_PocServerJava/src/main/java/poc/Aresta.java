package poc;

public class Aresta {
    String id;
    String descricao;

    public Aresta(String id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public String getId() {
        return this.id;
    }

    public String getDescricao() {
        return this.descricao;
    }
}