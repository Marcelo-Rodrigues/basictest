import { Component, OnInit } from '@angular/core';
import { Cliente } from '../cliente';
import { MatIconRegistry, MatAutocompleteSelectedEvent } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';

@Component({
  selector: 'app-campo-cliente',
  templateUrl: './campo-cliente.component.html',
  styleUrls: ['./campo-cliente.component.css']
})
export class CampoClienteComponent implements OnInit {
  controleCliente: FormControl;
  clientes: Cliente[];
  clientesFiltrados: Observable<Cliente[]>;
  clienteSelecionado: Cliente;
  exibirAutoComplete = true;

  constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    this.controleCliente = new FormControl();
    iconRegistry.addSvgIcon(
      'cliente',
      sanitizer.bypassSecurityTrustResourceUrl('assets/img/ic_face.svg'));
    iconRegistry.addSvgIcon(
      'empresa',
      sanitizer.bypassSecurityTrustResourceUrl('assets/img/ic_location_city.svg'));
  }

  ngOnInit() {
    this.clientes = [
      { cnpj: 25431231654151, tipo: '1', nome: 'Empresa A' },
      { cnpj: 2151515721, tipo: '2', nome: 'Cliente A' }
    ];

    this.clientesFiltrados = this.controleCliente.valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this.filtrarClientes(state) : this.clientes.slice())
      );

  }

  filtrarClientes(name: string) {
    return this.clientes.filter(cliente =>
      cliente.nome.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  aoSelecionarCliente(event: MatAutocompleteSelectedEvent) {
    this.exibirAutoComplete = false;
    this.clienteSelecionado = event.option.value;
  }
}
