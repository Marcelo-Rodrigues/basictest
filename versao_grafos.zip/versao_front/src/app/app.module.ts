import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { FormGrafoComponent } from './form-grafo/form-grafo.component';
import {
   MatAutocompleteModule, MatIconModule, MatFormFieldModule, MatDatepickerModule,   MatSelectModule, MatInputModule,
   MatCardModule, MatButtonModule, MatProgressSpinnerModule, MatMenuModule, MatChipsModule
 } from '@angular/material';
import { CampoClienteComponent } from './campo-cliente/campo-cliente.component';
import { CampoFiltroComponent } from './campo-filtro/campo-filtro.component';
import { ConsultaGrafoService } from './consulta-grafo.service';
import { ControleGrafoService } from './controle-grafo.service';

@NgModule({
  declarations: [
    AppComponent,
    FormGrafoComponent,
    CampoClienteComponent,
    CampoFiltroComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatAutocompleteModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatSelectModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatChipsModule
  ],
  providers: [ConsultaGrafoService, ControleGrafoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
