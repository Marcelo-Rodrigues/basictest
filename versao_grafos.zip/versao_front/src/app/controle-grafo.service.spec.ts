import { TestBed, inject } from '@angular/core/testing';

import { ControleGrafoService } from './controle-grafo.service';

describe('ControleGrafoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ControleGrafoService]
    });
  });

  it('should be created', inject([ControleGrafoService], (service: ControleGrafoService) => {
    expect(service).toBeTruthy();
  }));
});
