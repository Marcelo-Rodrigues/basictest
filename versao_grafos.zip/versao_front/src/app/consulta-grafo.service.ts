import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ConsultaGrafoService {

  constructor(private http: HttpClient) { }

  consultarGrafoCluster(codigoTipoCluster, codigoCluster, anoMes) {
    return this.http
      .get(`http://localhost:8080/api/cluster?codigoTipoCluster=${codigoTipoCluster}&codigoCluster=${codigoCluster}&anoMes=${anoMes}`);
  }

}


