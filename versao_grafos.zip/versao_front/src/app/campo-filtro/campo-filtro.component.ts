import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ConsultaGrafoService } from '../consulta-grafo.service';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ControleGrafoService } from '../controle-grafo.service';
import { MatMenuTrigger } from '@angular/material';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-campo-filtro',
  templateUrl: './campo-filtro.component.html',
  styleUrls: ['./campo-filtro.component.css']
})
export class CampoFiltroComponent implements OnInit {
  formConsulta: FormGroup;
  emCarregamento = false;
  @ViewChild('cy') cy: ElementRef;
  @ViewChild(MatMenuTrigger) menuExpansao: MatMenuTrigger;

  subscriptionRequisicaoGrafo: Subscription;
  inicioProcessamento = 0;
  tempoUltimoProcessamento = 0;

  constructor(private fb: FormBuilder, private servicoConsultaGrafo: ConsultaGrafoService,
    private servicoControleGrafo: ControleGrafoService) {
    this.criarForm();
  }

  criarForm() {
    this.formConsulta = this.fb.group({
      idTipoCluster: ['1', Validators.required],
      cluster: ['Aaa', Validators.required],
      valorCluster: ['201801', Validators.required]
    });
  }

  ngOnInit() {
  }

  aoConsultarGrafo(formulario) {
    this.emCarregamento = true;
    if (this.subscriptionRequisicaoGrafo) {
      this.subscriptionRequisicaoGrafo.unsubscribe();
    }

    this.inicioProcessamento = performance.now();

    this.subscriptionRequisicaoGrafo = this.servicoConsultaGrafo
      .consultarGrafoCluster(formulario.idTipoCluster, formulario.cluster, formulario.valorCluster)
      .subscribe(res => this.grafoRetornado(res), () => this.emCarregamento = false);
  }

  grafoRetornado(res) {
    this.emCarregamento = false;
    this.tempoUltimoProcessamento = performance.now() - this.inicioProcessamento;
    this.servicoControleGrafo.desenharGrafo(this.cy.nativeElement, res);
  }

  exibirMenu(vertice) {
    this.menuExpansao.openMenu();
  }

  get tempoUltimoProcessamentoSeg() {
    return Math.round(this.tempoUltimoProcessamento / 100) / 10;
  }
}
