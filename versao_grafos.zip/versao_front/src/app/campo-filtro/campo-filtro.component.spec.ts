import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CampoFiltroComponent } from './campo-filtro.component';

describe('CampoFiltroComponent', () => {
  let component: CampoFiltroComponent;
  let fixture: ComponentFixture<CampoFiltroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CampoFiltroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CampoFiltroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
