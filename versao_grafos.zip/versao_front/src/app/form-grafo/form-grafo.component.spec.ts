import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormGrafoComponent } from './form-grafo.component';

describe('FormGrafoComponent', () => {
  let component: FormGrafoComponent;
  let fixture: ComponentFixture<FormGrafoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormGrafoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormGrafoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
