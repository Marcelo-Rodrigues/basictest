import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-grafo',
  templateUrl: './form-grafo.component.html',
  styleUrls: ['./form-grafo.component.css']
})
export class FormGrafoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
