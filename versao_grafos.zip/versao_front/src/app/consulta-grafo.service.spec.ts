import { TestBed, inject } from '@angular/core/testing';

import { ConsultaGrafoService } from './consulta-grafo.service';

describe('ConsultaGrafoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConsultaGrafoService]
    });
  });

  it('should be created', inject([ConsultaGrafoService], (service: ConsultaGrafoService) => {
    expect(service).toBeTruthy();
  }));
});
