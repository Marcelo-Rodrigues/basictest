export class Cliente {
    cnpj: number;
    tipo: string;
    nome: string;
}
