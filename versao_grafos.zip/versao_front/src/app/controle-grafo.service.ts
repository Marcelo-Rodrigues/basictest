import { Injectable } from '@angular/core';

@Injectable()
export class ControleGrafoService {

  constructor() { }

  desenharGrafo(cy, dados) {
    const grafo = cytoscape({
      container: cy,
      elements: dados,
      layout: {
        name: 'cose'
      },
      style: [
        {
          selector: 'node',
          style: {
            'content': 'data(descricao)'
          }
        },
        {
          selector: 'edge',
          style: {
            'content': 'data(descricao)'
          }
        }
      ]
    });
  }
}
