USE [PocRelac]
GO
/****** Object:  StoredProcedure [dbo].[criarClientes]    Script Date: 14/04/2018 02:05:25 ******/
DROP PROCEDURE [dbo].[criarClientes]
GO
/****** Object:  StoredProcedure [dbo].[criarClientes]    Script Date: 14/04/2018 01:51:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON

GO
CREATE PROCEDURE [dbo].[criarClientes]
    (
    @Quantidade INT = 1,
    @Fl_Tipo DECIMAL(5,0) = 1
)
AS
BEGIN

    DECLARE
        @n INT,
        @n1 INT,
        @n2 INT,
        @n3 INT,
        @n4 INT,
        @n5 INT,
        @n6 INT,
        @n7 INT,
        @n8 INT,
        @n9 INT,
        @n10 INT,
        @n11 INT,
        @n12 INT,
    
        @d1 INT,
        @d2 INT



    -- CPF	
    IF (@Fl_Tipo = 1)
    BEGIN

        WHILE (@Quantidade > 0)
        BEGIN

            SET @n = 9
            SET @n1 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n2 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n3 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n4 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n5 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n6 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n7 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n8 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n9 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @d1 = @n9 * 2 + @n8 * 3 + @n7 * 4 + @n6 * 5 + @n5 * 6 + @n4 * 7 + @n3 * 8 + @n2 * 9 + @n1 * 10
            SET @d1 = 11 - ( @d1 % 11 )

            IF ( @d1 >= 10 )
                SET @d1 = 0

            SET @d2 = @d1 * 2 + @n9 * 3 + @n8 * 4 + @n7 * 5 + @n6 * 6 + @n5 * 7 + @n4 * 8 + @n3 * 9 + @n2 * 10 + @n1 * 11
            SET @d2 = 11 - ( @d2 % 11 )

            IF ( @d2 >= 10 )
                SET @d2 = 0


            DECLARE @CPF DECIMAL(14,0) = CONVERT(DECIMAL(14,0), CAST(@n1 AS VARCHAR) + CAST(@n2 AS VARCHAR) + CAST(@n3 AS VARCHAR) + CAST(@n4 AS VARCHAR) + CAST(@n5 AS VARCHAR) + CAST(@n6 AS VARCHAR) + CAST(@n7 AS VARCHAR) + CAST(@n8 AS VARCHAR) + CAST(@n9 AS VARCHAR) + CAST(@d1 AS VARCHAR) + CAST(@d2 AS VARCHAR))

            --SELECT CAST(@n1 AS VARCHAR) + CAST(@n2 AS VARCHAR) + CAST(@n3 AS VARCHAR) + '.' + CAST(@n4 AS VARCHAR) + CAST(@n5 AS VARCHAR) + CAST(@n6 AS VARCHAR) + '.' + CAST(@n7 AS VARCHAR) + CAST(@n8 AS VARCHAR) + CAST(@n9 AS VARCHAR) + '-' + CAST(@d1 AS VARCHAR) + CAST(@d2 AS VARCHAR)
            INSERT INTO Cliente
                (TIPO_PESSOA, CNPJ, NOME)
            SELECT @Fl_Tipo, @CPF, 'Cliente PF ' + CONVERT(VARCHAR(14),@CPF)

            SET @Quantidade = @Quantidade - 1

        END

    END

    -- CNPJ
    ELSE BEGIN

        WHILE (@Quantidade > 0)
        BEGIN

            SET @n = 9
            SET @n1 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n2 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n3 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n4 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n5 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n6 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n7 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n8 = CAST(( @n + 1 ) * RAND(CAST(NEWID() AS VARBINARY )) AS INT)
            SET @n9 = 0
            SET @n10 = 0
            SET @n11 = 0
            SET @n12 = 1

            SET @d1 = @n12 * 2 + @n11 * 3 + @n10 * 4 + @n9 * 5 + @n8 * 6 + @n7 * 7 + @n6 * 8 + @n5 * 9 + @n4 * 2 + @n3 * 3 + @n2 * 4 + @n1 * 5
            SET @d1 = 11 - ( @d1 % 11 )

            IF (@d1 >= 10) 
                SET @d1 = 0

            SET @d2 = @d1 * 2 + @n12 * 3 + @n11 * 4 + @n10 * 5 + @n9 * 6 + @n8 * 7 + @n7 * 8 + @n6 * 9 + @n5 * 2 + @n4 * 3 + @n3 * 4 + @n2 * 5 + @n1 * 6
            SET @d2 = 11 - ( @d2 % 11 )

            IF (@d2 >= 10) 
                SET @d2 = 0

            DECLARE @CNPJ DECIMAL(14,0) = CONVERT(DECIMAL(14,0), '' + CAST(@n1 AS VARCHAR) + CAST (@n2 AS VARCHAR) + CAST (@n3 AS VARCHAR) + CAST (@n4 AS VARCHAR) + CAST (@n5 AS VARCHAR) + CAST (@n6 AS VARCHAR) + CAST (@n7 AS VARCHAR) + CAST (@n8 AS VARCHAR) + CAST (@n9 AS VARCHAR) + CAST (@n10 AS VARCHAR) + CAST (@n11 AS VARCHAR) + CAST (@n12 AS VARCHAR) + CAST (@d1 AS VARCHAR) + CAST (@d2 AS VARCHAR))

            --SELECT '' + CAST(@n1 AS VARCHAR) + CAST (@n2 AS VARCHAR) + '.' + CAST (@n3 AS VARCHAR) + CAST (@n4 AS VARCHAR) + CAST (@n5 AS VARCHAR) + '.' + CAST (@n6 AS VARCHAR) + CAST (@n7 AS VARCHAR) + CAST (@n8 AS VARCHAR) + '/' + CAST (@n9 AS VARCHAR) + CAST (@n10 AS VARCHAR) + CAST (@n11 AS VARCHAR) + CAST (@n12 AS VARCHAR) + '-' + CAST (@d1 AS VARCHAR) + CAST (@d2 AS VARCHAR);
            INSERT INTO Cliente
                (TIPO_PESSOA, CNPJ, NOME)
            SELECT @Fl_Tipo, @CNPJ, 'Cliente PJ ' + CONVERT(VARCHAR(14),@CNPJ)

            SET @Quantidade = @Quantidade - 1

        END

    END

END
GO
DROP PROCEDURE [dbo].[criarOperacoes]
GO
SET NOCOUNT ON
GO
CREATE PROCEDURE criarOperacoes
    (
    @Quantidade INT = 1,
    @ANOMES_VIGENCIA int=201801)
as
BEGIN
    declare @Upper INT=10000000,@Lower INT=1,
	@AMOSTRA_INICIAL INT = @Quantidade + (@Quantidade * 0.10)
	
	SELECT TOP (@AMOSTRA_INICIAL) C.CNPJ, C.TIPO_PESSOA, row_number() over (order by C.CNPJ) as seqnum
	INTO #ORIGEM
	FROM Cliente c WHERE (ABS(CAST((BINARY_CHECKSUM(c.CNPJ, NEWID())) as int))% 100) < 10
	
	SELECT CNPJ, TIPO_PESSOA, row_number() over (order by C.CNPJ) as seqnum
	INTO #DESTINO
	FROM (
		SELECT TOP (@AMOSTRA_INICIAL) C.CNPJ, C.TIPO_PESSOA
		FROM Cliente c WHERE (ABS(CAST((BINARY_CHECKSUM(c.CNPJ, NEWID())) as int))% 100) < 10
		EXCEPT
		SELECT CNPJ, TIPO_PESSOA
		FROM #ORIGEM) AS C

    INSERT INTO [dbo].[Operacoes]
        ([ANOMES_VIGENCIA]
        ,[CNPJ_ORIGEM]
        ,[TIPO_PESSOA_ORIGEM]
        ,[CNPJ_DESTINO]
        ,[TIPO_PESSOA_DESTINO]
        ,[VALOR])

		SELECT top (@Quantidade)
			@ANOMES_VIGENCIA,
			CNPJ_ORIGEM
			,TIPO_PESSOA_ORIGEM
			,CNPJ_DESTINO
			,TIPO_PESSOA_DESTINO
			,ROUND(((@Upper - @Lower -1) * RAND(CNPJ_ORIGEM+CNPJ_DESTINO) + @Lower), 0)/100.
			FROM 
			(
				SELECT NOVA.* FROM
					(
					SELECT TOP (@Quantidade) O.CNPJ AS CNPJ_ORIGEM, O.TIPO_PESSOA AS TIPO_PESSOA_ORIGEM, D.CNPJ AS CNPJ_DESTINO, D.TIPO_PESSOA AS TIPO_PESSOA_DESTINO
					FROM #ORIGEM O INNER JOIN #DESTINO D on O.seqnum = D.seqnum
					WHERE O.CNPJ <> D.CNPJ) NOVA
				LEFT JOIN [Operacoes] O ON NOVA.CNPJ_ORIGEM = O.CNPJ_ORIGEM AND NOVA.CNPJ_DESTINO = O.CNPJ_DESTINO
				WHERE O.CNPJ_ORIGEM IS NULL
			) AS TB
			
	DROP TABLE #ORIGEM
	DROP TABLE #DESTINO
END
GO


DROP PROCEDURE [dbo].[criarClustersRating]
GO
SET NOCOUNT ON
GO
CREATE PROCEDURE [dbo].[criarClustersRating]
    (
    @ANOMES_VIGENCIA int=201801)
as
BEGIN
	DECLARE @MAX TINYINT

	SELECT @MAX = COUNT(*)
	FROM APOIO_DOMINIO_RATING
	SELECT @MAX
	INSERT INTO [dbo].[Cluster]
			([CODIGO_TIPO_CLUSTER]
			,[CODIGO_CLUSTER]
			,[CNPJ]
			,[TIPO_PESSOA]
			,[ANOMES_VIGENCIA])
    SELECT 1, R.RATING, C.CNPJ, C.TIPO_PESSOA, @ANOMES_VIGENCIA
	FROM Cliente C INNER JOIN APOIO_DOMINIO_RATING R ON R.ID = FLOOR(RAND(C.CNPJ/100000.)*(@MAX)+1)
END
GO

/*
 exec [ConsultaGrafoClusterCluster] 1, 'Aaa'
 exec [ConsultaGrafoClusterCluster] 1, 'A3'
 exec [ConsultaGrafoClusterCluster] 1, 'C'

 */

DROP PROCEDURE [dbo].[ConsultaGrafoClusterCluster]
GO
SET NOCOUNT ON
GO
CREATE PROCEDURE [dbo].[ConsultaGrafoClusterCluster]
    (@CODIGO_TIPO_CLUSTER INT = 1, @CODIGO_CLUSTER CHAR(5) = 'Aa3', @ANOMES_VIGENCIA int=201801)
as
BEGIN
	CREATE TABLE #CLUSTERS(CODIGO_CLUSTER_ORIGEM CHAR(5) NOT NULL, CODIGO_CLUSTER_DESTINO CHAR(5) NOT NULL, VALOR DECIMAL(20,4) NOT NULL, CODIGO_TIPO_PAGAMENTO INT NOT NULL)

	INSERT INTO #CLUSTERS
	SELECT       clu.CODIGO_CLUSTER, clu2.CODIGO_CLUSTER, sum(o.valor) valor, o.TIPO_PAGAMENTO
	FROM            Cluster AS clu INNER JOIN
							 Operacoes AS o ON o.CNPJ_ORIGEM = clu.CNPJ AND clu.TIPO_PESSOA = o.TIPO_PESSOA_ORIGEM INNER JOIN
						   Cluster AS clu2 ON o.CNPJ_DESTINO = clu2.CNPJ AND clu2.TIPO_PESSOA = o.TIPO_PESSOA_DESTINO
	WHERE        (clu.CODIGO_TIPO_CLUSTER = @CODIGO_TIPO_CLUSTER) AND (clu.CODIGO_CLUSTER = @CODIGO_CLUSTER) and clu.ANOMES_VIGENCIA = @ANOMES_VIGENCIA
	GROUP BY clu.CODIGO_CLUSTER, clu2.CODIGO_CLUSTER, o.TIPO_PAGAMENTO
	UNION ALL
	SELECT       clu.CODIGO_CLUSTER, clu2.CODIGO_CLUSTER, sum(o.valor) valor, o.TIPO_PAGAMENTO
	FROM            Cluster AS clu INNER JOIN
							 Operacoes AS o ON o.CNPJ_ORIGEM = clu.CNPJ AND clu.TIPO_PESSOA = o.TIPO_PESSOA_ORIGEM INNER JOIN
						   Cluster AS clu2 ON o.CNPJ_DESTINO = clu2.CNPJ AND clu2.TIPO_PESSOA = o.TIPO_PESSOA_DESTINO
	WHERE        (clu2.CODIGO_TIPO_CLUSTER = @CODIGO_TIPO_CLUSTER) AND (clu2.CODIGO_CLUSTER = @CODIGO_CLUSTER) and clu2.ANOMES_VIGENCIA = @ANOMES_VIGENCIA
	GROUP BY clu.CODIGO_CLUSTER, clu2.CODIGO_CLUSTER, o.TIPO_PAGAMENTO

	SELECT dc.CODIGO_CLUSTER, dc.DESCRICAO_CLUSTER
	FROM #CLUSTERS clu
		INNER JOIN DetalheCluster dc on clu.CODIGO_CLUSTER_ORIGEM = dc.CODIGO_CLUSTER
	UNION
	SELECT dc.CODIGO_CLUSTER, dc.DESCRICAO_CLUSTER
	FROM #CLUSTERS clu
		INNER JOIN DetalheCluster dc on clu.CODIGO_CLUSTER_DESTINO = dc.CODIGO_CLUSTER

	SELECT clu.CODIGO_CLUSTER_ORIGEM, clu.CODIGO_CLUSTER_DESTINO, VALOR, clu.CODIGO_TIPO_PAGAMENTO, tp.NOME AS DESCRICAO_TIPO_PAGAMENTO
	FROM #CLUSTERS clu inner join TipoPagamento tp on clu.CODIGO_TIPO_PAGAMENTO = tp.TIPO_PAGAMENTO
END

GO
GRANT EXECUTE ON [ConsultaGrafoClusterCluster] TO Poc

GO


--DROP PROCEDURE [dbo].[ConsultaGrafoClusterCluster_SR]
--GO
--SET NOCOUNT ON
--GO
--CREATE PROCEDURE [dbo].[ConsultaGrafoClusterCluster_SR]
--    (@CODIGO_TIPO_CLUSTER INT = 1, @CODIGO_CLUSTER CHAR(5) = 'Aa3', @ANOMES_VIGENCIA int=201801)
--as
--BEGIN
--	SELECT       clu.CODIGO_CLUSTER AS SOURCE, dc.DESCRICAO_CLUSTER AS DESCRICAO_CLUSTER, clu2.CODIGO_CLUSTER AS TARGET, dc2.DESCRICAO_CLUSTER AS DESCRICAO_TARGET, sum(o.valor) AS VALOR, o.TIPO_PAGAMENTO AS TIPO_PAGAMENTO
--	FROM            Cluster AS clu INNER JOIN
--							 Operacoes AS o ON o.CNPJ_ORIGEM = clu.CNPJ AND clu.TIPO_PESSOA = o.TIPO_PESSOA_ORIGEM INNER JOIN
--						   Cluster AS clu2 ON o.CNPJ_DESTINO = clu2.CNPJ AND clu2.TIPO_PESSOA = o.TIPO_PESSOA_DESTINO
--							INNER JOIN DetalheCluster dc on clu.CODIGO_CLUSTER = dc.CODIGO_CLUSTER
--							INNER JOIN DetalheCluster dc2 on clu2.CODIGO_CLUSTER = dc2.CODIGO_CLUSTER
--	WHERE        (clu.CODIGO_TIPO_CLUSTER = @CODIGO_TIPO_CLUSTER) AND (clu.CODIGO_CLUSTER = @CODIGO_CLUSTER) and clu.ANOMES_VIGENCIA = @ANOMES_VIGENCIA
--	GROUP BY clu.CODIGO_CLUSTER, dc.DESCRICAO_CLUSTER, clu2.CODIGO_CLUSTER, dc2.DESCRICAO_CLUSTER, o.TIPO_PAGAMENTO
--	UNION ALL
--	SELECT       clu.CODIGO_CLUSTER, dc.DESCRICAO_CLUSTER, clu2.CODIGO_CLUSTER, dc2.DESCRICAO_CLUSTER, sum(o.valor) valor, o.TIPO_PAGAMENTO
--	FROM            Cluster AS clu INNER JOIN
--							 Operacoes AS o ON o.CNPJ_ORIGEM = clu.CNPJ AND clu.TIPO_PESSOA = o.TIPO_PESSOA_ORIGEM INNER JOIN
--						   Cluster AS clu2 ON o.CNPJ_DESTINO = clu2.CNPJ AND clu2.TIPO_PESSOA = o.TIPO_PESSOA_DESTINO
--							INNER JOIN DetalheCluster dc on clu.CODIGO_CLUSTER = dc.CODIGO_CLUSTER
--							INNER JOIN DetalheCluster dc2 on clu2.CODIGO_CLUSTER = dc2.CODIGO_CLUSTER
--	WHERE        (clu2.CODIGO_TIPO_CLUSTER = @CODIGO_TIPO_CLUSTER) AND (clu2.CODIGO_CLUSTER = @CODIGO_CLUSTER) and clu2.ANOMES_VIGENCIA = @ANOMES_VIGENCIA
--	GROUP BY clu.CODIGO_CLUSTER, dc.DESCRICAO_CLUSTER, clu2.CODIGO_CLUSTER, dc2.DESCRICAO_CLUSTER, o.TIPO_PAGAMENTO

--END

--GO
--GRANT EXECUTE ON [ConsultaGrafoClusterCluster_SR] TO Poc
