USE [PocRelac]
GO

SET NOCOUNT ON

GO

--Criar Clientes PF
DECLARE @RC int
DECLARE @Quantidade int = 2800000
DECLARE @Fl_Tipo bit = 1

EXECUTE @RC = [dbo].[criarClientes]
   @Quantidade
  ,@Fl_Tipo
GO

--Criar Clientes PJ
DECLARE @RC int
DECLARE @Quantidade int = 3500000
DECLARE @Fl_Tipo bit = 2

EXECUTE @RC = [dbo].[criarClientes]
   @Quantidade
  ,@Fl_Tipo
GO

--Criar opera��es
declare @Quantidade int = 10000

WHILE (@Quantidade>0)
BEGIN
	exec criarOperacoes 2000
	set @Quantidade = @Quantidade - 1
END

go

--Criar clusters de ratings
exec [criarClustersRating]

go